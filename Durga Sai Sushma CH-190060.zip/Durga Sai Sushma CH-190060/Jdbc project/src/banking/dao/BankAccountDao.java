package banking.dao;
import java.sql.SQLException;
import java.util.ArrayList;

import banking.bean.BankAccount;




public interface BankAccountDao {
	public BankAccount CreateAccount(BankAccount account)throws ClassNotFoundException;
	
	public BankAccount displayBalance(int accountNo)throws ClassNotFoundException ;

	public BankAccount deposit(int accountNo, double amount) throws ClassNotFoundException;

	public BankAccount withdraw(int accountNo, double amount) throws ClassNotFoundException;

	public BankAccount fundTransfer(int accountNo1, int accountNo2, double amount)throws ClassNotFoundException;

	public ArrayList printDetails(int account_id)throws ClassNotFoundException, SQLException;

	
}
