package banking.service;

import java.sql.SQLException;
import java.util.ArrayList;

import banking.bean.BankAccount;


import banking.exception.InvalidAccountException;

public interface BankAccountService {
	public BankAccount CreateAccount(BankAccount account)throws ClassNotFoundException;
	
	public double displayBalance(int accountNo)throws ClassNotFoundException,InvalidAccountException ;

	public BankAccount deposit(int accountNo, double amount)throws ClassNotFoundException;

	public BankAccount withdraw(int accountNo, double amount)throws ClassNotFoundException;

	public BankAccount fundTransfer(int accountNo1, int accountNo2, double amount) throws ClassNotFoundException;

	public ArrayList printDetails(int accountNo)throws ClassNotFoundException, SQLException;
}
