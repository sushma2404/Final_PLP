package banking.ui;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import banking.bean.BankAccount;
import banking.exception.InvalidAccountException;
import banking.service.BankAccountService;
import banking.service.BankAccountServiceImpl;

public class BankAccountUI {
	static Scanner scanner = new Scanner(System.in);
	static int id=100;
	static BankAccountService service = new BankAccountServiceImpl();

	public static void main(String args[]) {
		do {
			System.out.println("Welcome to Bank");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			System.out.println("Enter your choice:");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				createAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
			  deposit();
				break;
			case 4:
				withdraw();
				break;
			case 5:
				fundTransfer();
				break;
			case 6:
				printTransactions();
				break;
			case 7:
				System.out.println("Do you want to exit:yes/no ");
				String ch = scanner.next();
				if (ch.toUpperCase().equals("YES"))
					System.exit(choice);
				break;
			default:
				System.out.println("You entered wrong input");
				System.out.println("Do you want to exit:yes/no ");
				String ch1 = scanner.next();
				if (ch1.toUpperCase().equals("YES"))
					System.exit(choice);
				break;
			}
		} while (true);
	}

	private static void createAccount() {
		// TODO Auto-generated method stub
		
		long phoneNo;
		long minBal;
		System.out.println("enter account holder name");
		String accName = scanner.next();
		boolean name = matches(accName);
		if (name == false) {
			System.err.println("Names must contain alphabets\n");
			return;
		}
		System.out.println("Enter phoneno");
		String phone = scanner.next();
		boolean number = matchPhoneNo(phone);
		if (number == false) {
			System.err.println("Phoneno must be valid\n");
			return;
		} else
			phoneNo = Long.parseLong(phone);
		System.out.println("Enter Initial balance");
		String balance = scanner.next();
		boolean bal = matchBalance(balance);
		if (bal == false) {
			System.err.println("Balance must contain digits\n");
			return;
		} else
			minBal = Long.parseLong(balance);
		int accountId=id++;
		BankAccount bankaccount = new BankAccount(accName, phoneNo, minBal);
		
		// System.out.println(bankaccount);
		try {
			service.CreateAccount(bankaccount);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static boolean matchAccountNo(String accountNo) {
		// TODO Auto-generated method stub
		return accountNo.matches("[0-9]+");
	}

	private static boolean matchBalance(String balance) {
		// TODO Auto-generated method stub
		return balance.matches("[0-9]+");
	}

	private static boolean matchPhoneNo(String phoneNo) {
		// TODO Auto-generated method stub

		return phoneNo.matches("\\d{10}");
	}

	public static boolean matches(String name) {
		return name.matches("[A-Z][a-z]*");

	}
	private static void showBalance() {
		// TODO Auto-generated method stub
		int accNo;
		System.out.println("Enter accountNo");
		String accountNo = scanner.next();
		boolean number = matchAccountNo(accountNo);
		if (number == false) {
			System.err.println("Enter valid accountNo\n");
			return;
		} else
			accNo = Integer.parseInt(accountNo);
		double balance;
		try {
			balance = service.displayBalance(accNo);
			System.out.println(balance);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAccountException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		}
	private static void deposit() {
		// TODO Auto-generated method stub
		int accNo;
		long amount;
		System.out.println("Enter the account you want to deposit:");
		String accountNo = scanner.next();
		boolean number = matchAccountNo(accountNo);
		if (number == false) {
			System.err.println("Enter valid accountNo\n");
			return;
		} else
			accNo = Integer.parseInt(accountNo);
		System.out.println("Enter the account you want to deposit:");

		System.out.println("Enter the amount you want to deposit:");
		String amt = scanner.next();
		boolean bal = matchBalance(amt);
		if (bal == false) {
			System.err.println("Balance must contain digits\n");
			return;
		} else
			amount = Long.parseLong(amt);
		
			try {
				service.deposit(accNo, amount);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
	private static void withdraw() {
		// TODO Auto-generated method stub
		int accNo;
		long amount;
		System.out.println("Enter from account you want to withdraw:");
		String accountNo = scanner.next();
		boolean number = matchAccountNo(accountNo);
		if (number == false) {
			System.err.println("Enter valid accountNo\n");
			return;
		} else
			accNo = Integer.parseInt(accountNo);

		System.out.println("Enter the amount you want to withdraw:");
		String amt = scanner.next();
		boolean bal = matchBalance(amt);
		if (bal == false) {
			System.err.println("Balance must contain digits\n");
			return;
		} else
			amount = Long.parseLong(amt);
		
			try {
				service.withdraw(accNo, amount);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
	}
	private static void fundTransfer() {
		// TODO Auto-generated method stub
		int accNo1;
		long amount;
		System.out.println("Enter from account you want to transfer:");
		String accountNo1 = scanner.next();
		boolean number = matchAccountNo(accountNo1);
		if (number == false) {
			System.err.println("Enter valid accountNo\n");
			return;
		} else
			accNo1 = Integer.parseInt(accountNo1);
		int accNo2;
		System.out.println("Enter to which account you want to transfer:");
		String accountNo2 = scanner.next();
		boolean num = matchAccountNo(accountNo2);
		if (num == false) {
			System.err.println("Enter valid accountNo\n");
			return;
		} else
			accNo2 = Integer.parseInt(accountNo2);
		System.out.println("Enter the amount");
		String amt = scanner.next();
		boolean bal = matchBalance(amt);
		if (bal == false) {
			System.err.println("Balance must contain digits\n");
			return;
		} else
			amount = Long.parseLong(amt);
		
			try {
				service.fundTransfer(accNo1, accNo2, amount);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	private static void printTransactions() {
		// TODO Auto-generated method stub
		int accNo;
		System.out.println("Enter accountNo");
		String accountNo = scanner.next();
		boolean number = matchAccountNo(accountNo);
		if (number == false) {
			System.err.println("Enter valid accountNo\n");
			return;
		} else
			accNo = Integer.parseInt(accountNo);
		
			try {
				
				ArrayList a=service.printDetails(accNo);
				for(Object i:a)
					System.out.println(i+"\n");
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

}




/*System.out.print("Enter Your Account Number to Know Your Transaction Details:");
account_id = sc.nextInt();
ArrayList a = bsi.printDetails(account_id);
System.out.println("Transaction_Id Account_Id    Transaction_Date     Transaction_Amount Transaction_Type");
System.out.println("_______________________________________________________________________________________");
for(Object i:a)
System.out.println(i+"\n");
System.out.println("_______________________________________________________________________________________");
break;*/