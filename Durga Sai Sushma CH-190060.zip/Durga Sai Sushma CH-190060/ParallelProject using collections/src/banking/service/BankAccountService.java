package banking.service;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;
import banking.exception.InsufficientBalanceException;
import banking.exception.InvalidAccountException;

public interface BankAccountService {
	public void CreateAccount(BankAccount bankaccount);

	public double displayBalance(int accountNo);

	public void deposit(int accountNo, double amount);

	public void withdraw(int accountNo, double amount);

	public void fundTransfer(int accountNo1, int accountNo2, double amount);

	public void printTransactions(int accountNo);
}
