package banking.dao;

import java.util.List;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;

public interface BankAccountDao {
	public void CreateAccount(BankAccount bankaccount);

	public BankAccount displayBalance(int accountNo);

	public BankAccount deposit(int accountNo, double amount);

	public BankAccount withdraw(int accountNo, double amount);

	public List<BankAccount> fundTransfer(int accountNo1, int accountNo2, double amount);

	public Transaction printTransactions(int accountNo);

	public void update(int accountNo, BankAccount bankAccount);
}
