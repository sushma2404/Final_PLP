package banking.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import banking.bean.BankAccount;
import banking.bean.Transaction;
import banking.exception.InsufficientBalanceException;
import banking.exception.InvalidAccountException;

public class BankAccountDaoImpl implements BankAccountDao {
	static List<BankAccount> list = new ArrayList<BankAccount>();
	static List<Transaction> transaction = new ArrayList<Transaction>();
	static BankAccount account = new BankAccount();
	int i = 0;

	@Override
	public void CreateAccount(BankAccount bankaccount) {
		// TODO Auto-generated method stub

		list.add(bankaccount);
		System.out.println("Account Created with accountId" + "  " + list.get(i).getAccountNo());
		// System.out.println("list data "+list);
		i++;

	}

	@Override
	public BankAccount displayBalance(int accountNo) {
		// TODO Auto-generated method stub
		int j = 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			int accNo = list.get(i).getAccountNo();
			if (accNo == accountNo) {
				j = i;
				count = 1;

			}
		}
		if (count == 1)
			return list.get(j);
		else
			return null;
	}

	@Override
	public BankAccount deposit(int accountNo, double amount) {
		// TODO Auto-generated method stub

		int j = 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			int accNo = list.get(i).getAccountNo();
			if (accNo == accountNo) {
				j = i;
				count = 1;

			}
		}
		if (count == 1)
			return list.get(j);
		else
			return null;

	}

	@Override
	public BankAccount withdraw(int accountNo, double amount) {
		// TODO Auto-generated method stub
		int j = 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			int accNo = list.get(i).getAccountNo();
			if (accNo == accountNo) {
				j = i;
				count = 1;

			}
		}
		if (count == 1)
			return list.get(j);
		else
			return null;
	}

	@Override
	public List<BankAccount> fundTransfer(int accountNo1, int accountNo2, double amount) {
		// TODO Auto-generated method stub
		List<BankAccount> transfer = new ArrayList<BankAccount>();
		for (int i = 0; i < list.size(); i++) {
			int accNo = list.get(i).getAccountNo();
			if (accNo == accountNo1 || accNo == accountNo2) {
				transfer.add(list.get(i));
			}
		}

		return transfer;

	}


	@Override
	public Transaction printTransactions(int accountNo) {
		int flag=0;
		Transaction t=null;
		if(true)
		{
		for (int i = 0; i < list.size(); i++) {
			if(accountNo==list.get(i).getAccountNo())
			{
				
				flag=1;	
				//System.out.println("flag");
			}
			
		}
		}
		 if(flag==1)
		{

		for (int i = 0; i < list.size(); i++) {
			int accountNum = list.get(i).getAccountNo();
			double initialBal = list.get(i).getInitialBalance();
			double finalBal = list.get(i).getAccountBalance();
			Transaction trans = new Transaction(accountNo, initialBal, finalBal);
			transaction.add(trans);
		}
		int j = 0;
		int count = 0;
		for (int i = 0; i < transaction.size(); i++) {
			int accNo = transaction.get(i).getAccountNo();
			if (accNo == accountNo) {
				j = i;
				count = 1;

			}
		}
		if (count == 1) 
			t= transaction.get(j);
		}
		 if(flag==0)
		{
			t=null;
		}
		//System.out.println(t);
		return t;
		
	}

	@Override
	public void update(int accountNo, BankAccount bankAccount) {
		// TODO Auto-generated method stub
		int j = 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			int accNo = list.get(i).getAccountNo();
			if (accNo == accountNo) {
				list.set(i, bankAccount);
			}
		}

	}

}
