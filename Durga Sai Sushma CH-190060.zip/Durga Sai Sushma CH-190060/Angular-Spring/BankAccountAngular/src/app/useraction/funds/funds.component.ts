import { Component, OnInit } from '@angular/core';
import { ServicelayerService } from 'src/app/servicelayer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-funds',
  templateUrl: './funds.component.html',
  styleUrls: ['./funds.component.css']
})
export class FundsComponent implements OnInit {
servicelayer:ServicelayerService;
router:Router;
  constructor(servicelayer:ServicelayerService,router:Router) {this.servicelayer=servicelayer;
  this.router=router }

  fundtransfer(data:any)
  {
let a=this.servicelayer.fundtransfer(data.accountnumber1,data.password1,data.accountnumber2,data.fundtransferamount);
a.subscribe((data) =>{
  alert("After fundtransfer balance is "+data);
  this.router.navigate(['useraction']);
},(error) =>{
  alert("enter correct details")
  this.router.navigate(['useraction']);
}) 
}

  ngOnInit() {
  }

}
