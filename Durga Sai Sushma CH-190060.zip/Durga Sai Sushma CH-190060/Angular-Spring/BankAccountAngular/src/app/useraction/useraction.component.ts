import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-useraction',
  templateUrl: './useraction.component.html',
  styleUrls: ['./useraction.component.css']
})
export class UseractionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
