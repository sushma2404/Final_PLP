package com.capg.mainui;

public class InvalidAccountException extends Exception{
	public InvalidAccountException(String msg){
		System.err.println(msg);
	}

}
